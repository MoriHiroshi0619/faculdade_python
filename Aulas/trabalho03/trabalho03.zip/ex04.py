distancia_inicial = 500
velocidade_tartaruga = 1
velocidade_lebre = 10
diferenca_velocidade = velocidade_lebre - velocidade_tartaruga
tempo_para_alcancar = distancia_inicial / diferenca_velocidade
print(f"Serão necessários {tempo_para_alcancar} minutos para a lebre alcançar a tartaruga.")
