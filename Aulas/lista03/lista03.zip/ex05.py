import functions

dia = int(input('Informe o dia de nascimento: '))
mes = int(input('Informe o mes de nascimento: '))

print(functions.getSigno(dia, mes))