import functions

dia = int(input('Informe o dia: '))
mes = int(input('Informe o mes: '))
ano = int(input('Informe o ano: '))

print(functions.proximo_dia(dia, mes, ano))