import functions

n = int(input("digite o numero de linhas do triangulo de pascal: "))
functions.imprimir_triangulo_pascal(n)