import functions

a = int(input("Informe o valor de a: "))

print(f'A soma de digitos de {a} é igual a {functions.soma_digitos(a)}')