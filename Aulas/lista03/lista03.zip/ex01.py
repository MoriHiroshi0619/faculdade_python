
for numero in range(1500, 2701):
    if numero % 7 == 0 and numero % 5 == 0:
        print(f"o {numero} é divisivel por 5 e 7")

