import functions

base = int(input("Informe o valor base: "))
exponente = int(input("Informe o valor exponente: "))

print(f'a base de {base} e o exponente de {exponente} é {functions.potencia(base, exponente)}')