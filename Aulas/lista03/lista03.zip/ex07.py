for i in range(1, 10):
    for _ in range(i):
        print(i, end="")
    print()