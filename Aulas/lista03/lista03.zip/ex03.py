import functions

letra = input("digite uma letra: ")
if functions.is_vogal(letra):
    print("é vogal")
else:
    print("num é vogal")