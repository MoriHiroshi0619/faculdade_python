import functions

a = int(input('Digite um valor: '))

print(f'{a} possui {functions.contar_digitos(a)}')