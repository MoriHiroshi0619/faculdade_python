import functions

inicio = int(input('Inicio: '))
fim = int(input('Fim: '))

print(f'os numeros pares entre {inicio} e {fim} é')
functions.imprimir_pares(inicio, fim)