import functions

n = int(input("digite um numer0: "))

functions.triangulo_invertido_pt2(n)