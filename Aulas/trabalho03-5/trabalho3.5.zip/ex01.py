import functions
n = int(input("valor de n: "))
resultado = functions.tribonacci(n)
print(f"O número de Tribonacci T({n}) é: {resultado}")
