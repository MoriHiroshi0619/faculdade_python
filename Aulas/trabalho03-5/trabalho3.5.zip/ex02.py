import functions

a = int(input("digite o numero inteiro positivo: "))
b = int(input("Digite o numero inteiro positivo: "))
resultado = functions.mdc(a, b)
print(f"O maximo divisor comum entre {a} e {b} é: {resultado}")