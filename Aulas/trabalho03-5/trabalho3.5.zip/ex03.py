import functions

n = int(input("digite um numer: "))

functions.triangulo_invertido(n)